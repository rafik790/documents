import requests
class RegistryModule:
    def __init__(self):
        self.result_count=0
        self.results=[]


class RegistryService:
    def __init__(self):
        self.apiUrlForNpi = "https://npiregistry.cms.hhs.gov/api?version=2.1&pretty=True"

    def execute(self,npi_id):
        prescrberObj=None
        apiUrl = (self.apiUrlForNpi+"&number={}").format(npi_id)
        print("apiUrl::",apiUrl)
        response1 = requests.get(apiUrl)
        todos1 = response1.json()
        if "results" in todos1:
            result_count = todos1.get('result_count')
            resResults = todos1.get('results')
            if result_count > 0:
                prescrberObj = resResults[0]
        return prescrberObj

    def executeWith(self,first_name,last_name,state_code):
        registry = RegistryModule()
        if state_code=="":
            apiUrl = (self.apiUrlForNpi+"&first_name={}&last_name={}").format(first_name,last_name)
        else:
            apiUrl = (self.apiUrlForNpi + "&first_name={}&last_name={}&state={}").format(first_name, last_name,
                                                                                         state_code)

        print("apiUrl::",apiUrl)
        response1 = requests.get(apiUrl)
        todos1 = response1.json()
        if "results" in todos1:
            registry.result_count = todos1.get('result_count')
            registry.results = todos1.get('results')
        return registry