from difflib import SequenceMatcher

from core.registeryservice import RegistryService
import re

class ReturnModule:
    def __init__(self):
        self.merger_flag=""
        self.comment=""
        self.profile1_exit_resistry = False
        self.profile2_exit_resistry = False


class SOPLogic:
    def __init__(self,dataRow):
        self.dataRow = dataRow

    def sopCaseOne(self):
        returnModule = ReturnModule()
        registryService = RegistryService()
        if self.dataRow.npi_1 != "" and self.dataRow.npi_2 != "":
            nameMatchRatio = SequenceMatcher(None, self.dataRow.name_1, self.dataRow.name_2).ratio()
            addressMatchRatio = SequenceMatcher(None, self.dataRow.address_1, self.dataRow.address_2).ratio()
            if self.dataRow.npi_1 == self.dataRow.npi_2 and nameMatchRatio==1 and addressMatchRatio==1:
                returnModule.merger_flag = "Y"
                returnModule.comment = "CASE 1: Both NPIs are same.The Name and Primary Addresses are Exactly Same"
            elif self.dataRow.npi_1 == self.dataRow.npi_2:
                returnModule = self.sopCaseThree()
                if returnModule.merger_flag=="Y":
                    returnModule.comment="CASE 1: Both NPIs are same"

            elif self.dataRow.npi_1 != self.dataRow.npi_2:
                # CODE TO FETCH DATA FROM REGISTRY
                prescrberJson_1 = registryService.execute(self.dataRow.npi_1)
                print(prescrberJson_1)
                if prescrberJson_1 is not None:
                    first_name_1 = prescrberJson_1.get("basic").get("first_name")
                    last_name_1 = prescrberJson_1.get("basic").get("last_name")
                    credential_1 = prescrberJson_1.get("basic").get("credential")
                    full_name_1 = prescrberJson_1.get("basic").get("name")
                    gender_1 = prescrberJson_1.get("basic").get("gender")
                    returnModule.profile1_exit_resistry = True

                prescrberJson_2 = registryService.execute(self.dataRow.npi_2)
                if prescrberJson_2 is not None:
                    first_name_2 = prescrberJson_2.get("basic").get("first_name")
                    last_name_2 = prescrberJson_2.get("basic").get("last_name")
                    credential_2 = prescrberJson_2.get("basic").get("credential")
                    full_name_2 = prescrberJson_2.get("basic").get("name")
                    gender_2 = prescrberJson_2.get("basic").get("gender")
                    returnModule.profile2_exit_resistry = True
                # END-CODE TO FETCH DATA FROM REGISTRY

                if returnModule.profile1_exit_resistry == True and returnModule.profile2_exit_resistry == True:
                    full_name_ratio = SequenceMatcher(None, full_name_1, full_name_2).ratio()
                    if full_name_ratio < .8:
                        returnModule.merger_flag = "N"
                        returnModule.comment = "CASE 1:(ii)Both NPIs are different and exist in registry. But name are different in registry"
                    elif full_name_ratio > .9 and (gender_1 != gender_2 or credential_1 != credential_2):
                        returnModule.merger_flag = "N"
                        returnModule.comment = "CASE 1:(ii)Both NPIs are different and exist in registry. But name are same in registry but other informations are different"
                elif returnModule.profile1_exit_resistry == False and returnModule.profile2_exit_resistry == True:
                    returnModule.merger_flag = "Y"
                    returnModule.merger_flag = "CASE 1:(ii) One of NPIs is exist in registry."
                elif returnModule.profile1_exit_resistry == True and returnModule.profile2_exit_resistry == False:
                    returnModule.merger_flag = "Y"
                    returnModule.comment = "CASE 1:(ii) One of NPIs is exist in registry."
                elif returnModule.profile1_exit_resistry == False and returnModule.profile2_exit_resistry == False:
                    # THIS CONDITION NEED TO ASK DS TEAM
                    returnModule.merger_flag = "N"
                    returnModule.comment = "CASE 1:(ii) Both NPIs are not exist in registry."

        elif (self.dataRow.npi_1 == "" and self.dataRow.npi_2 != "") \
                or (self.dataRow.npi_1 != "" and self.dataRow.npi_2 == ""):
            # TODO
            returnModule.merger_flag = ""
            returnModule.comment = "CASE 1:(iii) NPI is mentioned for only one of the two profiles."

        return returnModule;

    def sopCaseTwo(self):
        returnModule = ReturnModule()

        address_1_all = re.sub('\r?\n', '', self.dataRow.address_1_all)
        address_1_all_arr = re.split('\|Y|\|N', address_1_all)
        address_1_all_arr.append(self.dataRow.address_1)

        address_2_all = re.sub('\r?\n', '', self.dataRow.address_2_all)
        address_2_all_arr = re.split('\|Y|\|N', address_2_all)
        address_2_all_arr.append(self.dataRow.address_2)

        for address_1_str in address_1_all_arr:
            if address_1_str=="":
                continue
            for address_2_str in address_2_all_arr:
                nameMatchRatio = SequenceMatcher(None, address_1_str, address_2_str).ratio()
                if nameMatchRatio>0.95:
                    returnModule.merger_flag = "Y"
                    returnModule.comment = "CASE 2:primary or secondary addresses across the profiles match"
                    break
            if returnModule.merger_flag!="":
                break
        if returnModule.merger_flag!="":
            return returnModule

        return returnModule

    def sopCaseThree(self):
        returnModule = ReturnModule()
        registryService = RegistryService()
        name_1_token = self.dataRow.name_1.split()
        first_name_1 = name_1_token[0]
        last_name_1 = name_1_token[len(name_1_token)-1]
        state_code_1 = ""

        """
        address_1_token = self.dataRow.address_1.split()
        address_1_token = address_1_token[:-1]
        for add_part in reversed(address_1_token):
            if len(add_part)==2:
                state_code_1=add_part
                break
        
        """

        registryModule1 = registryService.executeWith(first_name_1,last_name_1,state_code_1)
        number_1=-1
        print("result_count_1::", registryModule1.result_count)
        if registryModule1.result_count>0:
            number_1 = 0
            for json in registryModule1.results:
                if json.get("number")==int(self.dataRow.npi_1):
                    number_1 = json.get("number")
                    break

        name_2_token = self.dataRow.name_2.split()
        first_name_2 = name_2_token[0]
        last_name_2 = name_2_token[len(name_2_token) - 1]
        state_code_2 = ""
        """
        address_2_token = self.dataRow.address_2.split()
        address_2_token = address_2_token[:-1]
        for add_part in reversed(address_2_token):
            if len(add_part) == 2:
                state_code_2 = add_part
                break
        """

        number_2=-1
        registryModule2 = registryService.executeWith(first_name_2, last_name_2, state_code_2)
        print("result_count_2::", registryModule2.result_count)
        if registryModule2.result_count > 0:
            number_2 = 0
            for json in registryModule2.results:
                if json.get("number")== int(self.dataRow.npi_2):
                    number_2 = json.get("number")
                    break

        print("number_1::",number_1," number_2::",number_2)
        if (number_1==number_2 and number_1==int(self.dataRow.npi_1)) \
                or (number_2==-1 and number_1==int(self.dataRow.npi_1)) \
                or (number_1==-1 and number_2==int(self.dataRow.npi_2)):
            print("I am here")
            returnModule.merger_flag = "Y"
            returnModule.comment = "CASE 3: If the names are different, and the NPIs and Primary Addresses match"
            return returnModule


        nameMatchRatio = SequenceMatcher(None, self.dataRow.name_1, self.dataRow.name_2).ratio()
        print("Name Match Ratio::",nameMatchRatio)
        if nameMatchRatio>=.80:
            returnModule.merger_flag = "Y"
            returnModule.comment = "CASE 3: If the names are different, and the NPIs and Primary Addresses match"
        else:
            returnModule.merger_flag = ""
            returnModule.comment = "CASE 3: If the names are different, and the NPIs and Primary Addresses match"

        return returnModule