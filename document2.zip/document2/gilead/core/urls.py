from django.urls import include, path,re_path
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework_simplejwt import views as jwt_views

from . import views
from rest_framework import routers
app_name = 'core'

router = routers.DefaultRouter()
#router.register(r'categories', ViewSets.CategoryViewSet)
router.register(r'upload', views.UploadViewSet, basename="upload")

urlpatterns = [
    path('', include(router.urls)),
    path('hello/', views.HelloView.as_view(), name='hello'),
    path('hello-token/', views.TokenHelloView.as_view(), name='hello-token'),
    path('api-token-auth/', obtain_auth_token, name='api_token_auth'),
    path('jwt-token/', views.MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('jwt-token-refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
    path('data-list/', views.DataListView.as_view(), name='data-list'),
    path('process-data/', views.ProcessDataView.as_view(), name='process-data'),
    path('file-record-summary/<int:uploadfile_id>', views.FileSummaryView.as_view(), name='file-record-summary'),
    path('processed-data-list/', views.ProcessedDataListView.as_view(), name='processed-data-list'),
    path('data-view/<int:data_id>', views.TaskDetailView.as_view(), name='data-view'),
]
