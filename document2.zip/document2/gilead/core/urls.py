from django.urls import include, path,re_path
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework_simplejwt import views as jwt_views

from . import views
from rest_framework import routers
app_name = 'core'

router = routers.DefaultRouter()
#router.register(r'categories', ViewSets.CategoryViewSet)
router.register(r'upload', views.UploadViewSet, basename="upload")

urlpatterns = [
    path('', include(router.urls)),
    path('hello/', views.HelloView.as_view(), name='hello'),
    path('hello-token/', views.TokenHelloView.as_view(), name='hello-token'),
    path('api-token-auth/', obtain_auth_token, name='api_token_auth'),
    path('jwt-token/', views.MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('jwt-token-refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
    path('unprocess-data-list/', views.UnProcessedDataListView.as_view(), name='data-list'),
    path('processed-data-list/', views.ProcessedDataListView.as_view(), name='processed-data-list'),
    path('get-record-summary/', views.RecordSummaryView.as_view(), name='get-record-summary'),
    path('process-data/', views.ProcessDataView.as_view(), name='process-data'),
    path('data-view/<int:data_id>', views.TaskDetailView.as_view(), name='data-view'),
    path('override-prediction/<int:data_id>', views.OverridePredicationView.as_view(), name='override-prediction'),
]
