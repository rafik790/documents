from django.db import models

# Create your models here.
class UploadedFile(models.Model):
    orginal_file = models.CharField(max_length=250,blank=True)
    actual_file = models.CharField(max_length=250,blank=True)
    data_type = models.CharField(max_length=3,blank=True)
    created_tm = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    def __str__(self):
        return self.orginal_file+' '+self.actual_file

class HCPRawData(models.Model):
    task_no = models.CharField(max_length=25, blank=True)
    ind_id = models.CharField(max_length=25, blank=True)
    row_id_1 = models.CharField(max_length=15, blank=True)
    row_id_2 = models.CharField(max_length=15, blank=True)
    name_1 = models.CharField(max_length=250, blank=True)
    name_2 = models.CharField(max_length=250, blank=True)
    eid_1 = models.CharField(max_length=15, blank=True)
    eid_2 = models.CharField(max_length=15, blank=True)
    prof_desig_1 = models.CharField(max_length=100, blank=True)
    prof_desig_2 = models.CharField(max_length=100, blank=True)
    entity_class_1 = models.CharField(max_length=10, blank=True)
    entity_class_2 = models.CharField(max_length=10, blank=True)
    address_1 = models.CharField(max_length=250, blank=True)
    address_1_all = models.CharField(max_length=1050, blank=True)
    address_2 = models.CharField(max_length=250, blank=True)
    address_2_all = models.CharField(max_length=1050, blank=True)
    npi_1 = models.CharField(max_length=25,blank=True)
    npi_2 = models.CharField(max_length=25,blank=True)
    me_1 = models.CharField(max_length=25, blank=True)
    me_2 = models.CharField(max_length=25, blank=True)
    ims_1 = models.CharField(max_length=25, blank=True)
    ims_2 = models.CharField(max_length=25, blank=True)
    is_processed = models.BooleanField(default=False)
    is_merge = models.BooleanField(default=False)
    is_overridden = models.BooleanField(default=False)
    comment = models.CharField(max_length=1050, blank=True)
    enriched_data = models.CharField(max_length=2500, blank=True)
    uploaded_file = models.ForeignKey(UploadedFile, on_delete=models.CASCADE, related_name="data_rows", blank=True, null=True)

    def __str__(self):
        return self.task_no+' '+self.npi_1+' '+self.npi_2
