from django.core.files.storage import FileSystemStorage
from django.db.models import Q, Count
import os
import openpyxl
from rest_framework_simplejwt.views import TokenObtainPairView
# Create your views here.
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import ViewSet

from core.bulkmanager import BulkCreateManager
from core.models import HCPRawData, UploadedFile
from core.serializers import UploadSerializer, CustomTokenObtainPairSerializer
import pandas as pd

from core.soplogic import SOPLogic, ReturnModule


class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


class HelloView(APIView):
    def get(self, request):
        content = {'message': 'Hello, World!'}
        return Response(content)


class TokenHelloView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        content = {'message': 'Hello, World! with token authentication'}
        return Response(content, status=status.HTTP_200_OK)


class UploadViewSet(ViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = UploadSerializer

    def list(self, request):
        return Response("GET API")

    def create(self, request):
        try:
            secondsSinceEpoch = time.time()
            file_uploaded = request.FILES.get('file_uploaded')

            ext = os.path.splitext(file_uploaded.name)[1].lower()[1:]
            org_file_name = file_uploaded.name
            new_file_name = str(secondsSinceEpoch) + "." + ext
            fs = FileSystemStorage()

            filename = fs.save(new_file_name, file_uploaded)
            uploaded_file_url = fs.url(filename)
            content_type = file_uploaded.content_type

            uploadeFile = UploadedFile()
            uploadeFile.actual_file = new_file_name
            uploadeFile.orginal_file = org_file_name
            uploadeFile.save()
            #self.parseUploadedFile(uploadeFile)
            self.parseUploadedFileWihOpenpyxl(uploadeFile)
            data = {
                "uploaded_file_url": uploaded_file_url,
                "filename": new_file_name,
                "content_type": content_type,
                "uploadedfile_id": uploadeFile.id,
            }

            return Response(data, status=status.HTTP_200_OK)
        except Exception as e:
            data = {"code": 500, "detail": str(e)}
            return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def parseUploadedFileWihOpenpyxl(self, uploadeFile):
        file_name = uploadeFile.actual_file
        fs = FileSystemStorage();

        file_path = fs.base_location + '\\' + file_name
        wb_obj = openpyxl.load_workbook(file_path)
        sheet_obj = wb_obj.active
        max_col = sheet_obj.max_column
        m_row = sheet_obj.max_row + 1

        bulk_mgr = BulkCreateManager(chunk_size=40)
        for irownm in range(2, m_row):
            column=1
            task_no = sheet_obj.cell(row=irownm, column=column).value
            if task_no == None:
                task_no = ""

            column+=1
            ind_id = sheet_obj.cell(row=irownm, column=column).value
            if ind_id == None:
                ind_id = ""

            column += 1
            row_id_1 = sheet_obj.cell(row=irownm, column=column).value
            if row_id_1 == None:
                row_id_1 = ""

            column += 1
            row_id_2 = sheet_obj.cell(row=irownm, column=column).value
            if row_id_2 == None:
                row_id_2 = ""

            column += 1
            name_1 = sheet_obj.cell(row=irownm, column=column).value
            if name_1 == None:
                name_1 = ""

            column += 1
            eid_1 = sheet_obj.cell(row=irownm, column=column).value
            if eid_1 == None:
                eid_1 = ""

            column += 1
            eid_2 = sheet_obj.cell(row=irownm, column=column).value
            if eid_2 == None:
                eid_2 = ""

            column += 1
            name_2 = sheet_obj.cell(row=irownm, column=column).value
            if name_2 == None:
                name_2 = ""

            column += 1
            prof_desig_1 = sheet_obj.cell(row=irownm, column=column).value
            if prof_desig_1 == None:
                prof_desig_1 = ""

            column += 1
            prof_desig_2 = sheet_obj.cell(row=irownm, column=column).value
            if prof_desig_2 == None:
                prof_desig_2 = ""

            column += 1
            entity_class_1 = sheet_obj.cell(row=irownm, column=column).value
            if entity_class_1 == None:
                entity_class_1 = ""

            column += 1
            entity_class_2 = sheet_obj.cell(row=irownm, column=column).value
            if entity_class_2 == None:
                entity_class_2 = ""

            column += 1
            address_1 = sheet_obj.cell(row=irownm, column=column).value
            if address_1 == None:
                address_1 = ""

            column += 1
            address_1_all = sheet_obj.cell(row=irownm, column=column).value
            if address_1_all == None:
                address_1_all = ""

            column += 1
            address_2 = sheet_obj.cell(row=irownm, column=column).value
            if address_2 == None:
                address_2 = ""

            column += 1
            address_2_all = sheet_obj.cell(row=irownm, column=column).value
            if address_2_all == None:
                address_2_all = ""

            column += 1
            npi_1 = sheet_obj.cell(row=irownm, column=column).value
            if npi_1 == None:
                npi_1 = ""

            column += 1
            npi_2 = sheet_obj.cell(row=irownm, column=column).value
            if npi_2 == None:
                npi_2 = ""

            column += 1
            me_1 = sheet_obj.cell(row=irownm, column=column).value
            if me_1 == None:
                me_1 = ""

            column += 1
            me_2 = sheet_obj.cell(row=irownm, column=column).value
            if me_2 == None:
                me_2 = ""

            column += 1
            ims_1 = sheet_obj.cell(row=irownm, column=column).value
            if ims_1 == None:
                ims_1 = ""

            column += 1
            ims_2 = sheet_obj.cell(row=irownm, column=column).value
            if ims_2 == None:
                ims_2 = ""

            bulk_mgr.add(HCPRawData(task_no=task_no,
                                 ind_id=ind_id,
                                 row_id_1=row_id_1,
                                 row_id_2=row_id_2,
                                 name_1=name_1,
                                 name_2=name_2,
                                 eid_1=eid_1,
                                 eid_2=eid_2,
                                 prof_desig_1=prof_desig_1,
                                 prof_desig_2=prof_desig_2,
                                 entity_class_1=entity_class_1,
                                 entity_class_2=entity_class_2,
                                 address_1=address_1,
                                 address_1_all=address_1_all,
                                 address_2=address_2,
                                 address_2_all=address_2_all,
                                 npi_1=npi_1,
                                 npi_2=npi_2,
                                 me_1=me_1,
                                 me_2=me_2,
                                 ims_1=ims_1,
                                 ims_2=ims_2,
                                 uploaded_file=uploadeFile,
                                 is_processed=False,
                                 is_merge=False))
        bulk_mgr.done()


class DataListView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        uploadfile_id = request.data["uploadfile_id"]
        page_no = request.data["page_no"]
        page_size = request.data["page_size"]
        is_processed = request.data["is_processed"]
        order_by = request.data["order_by"]
        try:
            offset = (int(page_no) - 1) * int(page_size)
            end_index = offset + int(page_size)

            print("page_no={} , page_size={}, offset={}, end_index={}".format(page_no, page_size, offset, end_index))

            qs_rawdata_lst = HCPRawData.objects.distinct().filter(uploaded_file__id=uploadfile_id,is_processed=is_processed);
            data_list = [];
            for datarow in qs_rawdata_lst.order_by(order_by)[offset:end_index]:
                data_obj = {
                    "data_id": datarow.id,
                    "task_no": datarow.task_no,
                    "row_id_1":datarow.row_id_1,
                    "row_id_2": datarow.row_id_2,
                    "name_1": datarow.name_1,
                    "name_2": datarow.name_2,
                    "eid_1": datarow.eid_1,
                    "eid_2": datarow.eid_2,
                    "prof_desig_1": datarow.prof_desig_1,
                    "prof_desig_2": datarow.prof_desig_2,
                    "entity_class_1": datarow.entity_class_1,
                    "entity_class_2": datarow.entity_class_2,
                    "address_1": datarow.address_1,
                    "address_1_all": datarow.address_1_all,
                    "address_2": datarow.address_2,
                    "address_2_all": datarow.address_2_all,
                    "npi_1": datarow.npi_1,
                    "npi_2": datarow.npi_2,
                    "me_1": datarow.me_1,
                    "me_2": datarow.me_2,
                    "ims_1": datarow.ims_1,
                    "ims_2": datarow.ims_2,
                    "comment": datarow.comment,
                    "is_processed": datarow.is_processed,
                    "is_merge": datarow.is_merge,
                    "is_processing": False
                }
                data_list.append(data_obj)

            data = {
                "code": 200,
                "detail": "Successfully done",
                "data_list": data_list
            }
            return Response(data, status=status.HTTP_200_OK)
        except  Exception as e:
            data = {"code": 500, "detail": str(e)}
            return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ProcessedDataListView(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request):
        uploadfile_id = request.data["uploadfile_id"]
        start = request.data["start"]
        length = request.data["length"]
        draw = request.data["draw"]
        order_by = request.data["order_by"]
        search_txt = request.data["search"]

        try:
            offset = int(start)
            end_index = offset + int(length)

            qs_rawdata_lst = HCPRawData.objects.distinct().filter(uploaded_file__id=uploadfile_id,
                                                               is_processed=True);
            data_list = []

            recordsTotal = qs_rawdata_lst.count()
            recordsFiltered = recordsTotal

            if search_txt != "":
                qs_rawdata_lst = qs_rawdata_lst.filter(
                    (Q(npi_1__icontains=search_txt) |
                     Q(npi_2__icontains=search_txt)|
                     Q(name_1__icontains=search_txt)|
                     Q(name_2__icontains=search_txt))
                )
                recordsFiltered = qs_rawdata_lst.count()


            for datarow in qs_rawdata_lst.order_by(order_by)[offset:end_index]:
                data_obj = {
                    "data_id": datarow.id,
                    "task_no": datarow.task_no,
                    "row_id_1":datarow.row_id_1,
                    "row_id_2": datarow.row_id_2,
                    "name_1": datarow.name_1,
                    "name_2": datarow.name_2,
                    "eid_1": datarow.eid_1,
                    "eid_2": datarow.eid_2,
                    "prof_desig_1": datarow.prof_desig_1,
                    "prof_desig_2": datarow.prof_desig_2,
                    "entity_class_1": datarow.entity_class_1,
                    "entity_class_2": datarow.entity_class_2,
                    "address_1": datarow.address_1,
                    "address_1_all": datarow.address_1_all,
                    "address_2": datarow.address_2,
                    "address_2_all": datarow.address_2_all,
                    "npi_1": datarow.npi_1,
                    "npi_2": datarow.npi_2,
                    "me_1": datarow.me_1,
                    "me_2": datarow.me_2,
                    "ims_1": datarow.ims_1,
                    "ims_2": datarow.ims_2,
                    "is_processed": datarow.is_processed,
                    "is_merge": datarow.is_merge,
                    "comment": datarow.comment,
                    "is_processing": False,
                }
                data_list.append(data_obj)

            data = {
                "code": 200,
                "detail": "Successfully done",
                "recordsTotal":recordsTotal,
                "recordsFiltered":recordsFiltered,
                "data_list": data_list
            }
            return Response(data, status=status.HTTP_200_OK)
        except  Exception as e:
            data = {"code": 500, "detail": str(e)}
            return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class FileSummaryView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, uploadfile_id):
        try:
            totalrecords = HCPRawData.objects.distinct().filter(uploaded_file__id=uploadfile_id).count();
            total_processed_records = HCPRawData.objects.distinct().filter(uploaded_file__id=uploadfile_id,
                                                                     is_processed=True).count();
            total_merged_records = HCPRawData.objects.distinct().filter(uploaded_file__id=uploadfile_id,
                                                                     is_processed=True,
                                                                     is_merge=True).count();
            total_unmerged_records = HCPRawData.objects.distinct().filter(uploaded_file__id=uploadfile_id,
                                                                       is_processed=True,
                                                                       is_merge=False).count();

            data = {
                "code": 200,
                "detail": "Successfully done",
                "data":{
                    "total_records": totalrecords,
                    "total_processed_records": total_processed_records,
                    "total_merged_records": total_merged_records,
                    "total_unmerged_records": total_unmerged_records,
                }

            }
            return Response(data, status=status.HTTP_200_OK)
        except  Exception as e:
            data = {"code": 500, "detail": str(e)}
            return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

import random
import time
from difflib import SequenceMatcher
class ProcessDataView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        data_id = request.data["data_id"]

        try:
            datarow = HCPRawData.objects.get(id=data_id)

            nameMatchRatio = SequenceMatcher(None,datarow.name_1,datarow.name_2).ratio()
            primaryAddressMatchRatio = SequenceMatcher(None, datarow.address_1, datarow.address_2).ratio()
            print("NameMatchRatio:{} AddressMatchRatio:{}".format(nameMatchRatio,primaryAddressMatchRatio))
            sopLogic = SOPLogic(datarow)
            returnModule = ReturnModule()
            bothNPIExit = (datarow.npi_1!="" and datarow.npi_2!="")
            exactMatchThresold=.9;
            if nameMatchRatio>=exactMatchThresold and primaryAddressMatchRatio>=exactMatchThresold:
                # CASE 1:
                returnModule = sopLogic.sopCaseOne()
            elif bothNPIExit==True and nameMatchRatio>=exactMatchThresold and datarow.npi_1==datarow.npi_2 \
                    and  primaryAddressMatchRatio<exactMatchThresold:
                # CASE 2:
                returnModule = sopLogic.sopCaseTwo()

            elif bothNPIExit==True and primaryAddressMatchRatio>=exactMatchThresold \
                    and datarow.npi_1==datarow.npi_2:
                # CASE 3:
                returnModule = sopLogic.sopCaseThree()
            elif bothNPIExit==True and primaryAddressMatchRatio < exactMatchThresold and nameMatchRatio < exactMatchThresold:
                # CASE 4:
                returnModule.merger_flag = ""
                returnModule.comment = "CASE 4:Both Names and Primary Addresses are not matching."
            elif bothNPIExit==True and primaryAddressMatchRatio>=exactMatchThresold and nameMatchRatio < exactMatchThresold:
                #CASE 5:
                returnModule.merger_flag = "N"
                returnModule.comment = "CASE 5:Names are not matching and Primary Addresses are matching, but NPIs for one/both profiles are not present."

            elif bothNPIExit==False:
                returnModule.merger_flag = "N"
                returnModule.comment = "One/Both the NPIs are missing."


            #randomNumber = random.randint(0,1);
            datarow.is_processed = True
            if returnModule.merger_flag=="Y":
                datarow.is_merge = True
            else:
                datarow.is_merge = False
            datarow.comment = returnModule.comment;
            datarow.save()

            data_obj = {
                "data_id": datarow.id,
                "task_no": datarow.task_no,
                "row_id_1":datarow.row_id_1,
                "row_id_2": datarow.row_id_2,
                "name_1": datarow.name_1,
                "name_2": datarow.name_2,
                "eid_1": datarow.eid_1,
                "eid_2": datarow.eid_2,
                "prof_desig_1": datarow.prof_desig_1,
                "prof_desig_2": datarow.prof_desig_2,
                "entity_class_1": datarow.entity_class_1,
                "entity_class_2": datarow.entity_class_2,
                "address_1": datarow.address_1,
                "address_1_all": datarow.address_1_all,
                "address_2": datarow.address_2,
                "address_2_all": datarow.address_2_all,
                "npi_1": datarow.npi_1,
                "npi_2": datarow.npi_2,
                "me_1": datarow.me_1,
                "me_2": datarow.me_2,
                "ims_1": datarow.ims_1,
                "ims_2": datarow.ims_2,
                "is_processed": datarow.is_processed,
                "is_merge": datarow.is_merge,
                "comment":datarow.comment,
                "is_processing": False,
                "mergeFlag": returnModule.merger_flag
                
            }

            data = {
                "code": 200,
                "detail": "Successfully done",
                "data": data_obj
            }
            #time.sleep(10)
            return Response(data, status=status.HTTP_200_OK)
        except  Exception as e:
            print(e)
            data = {"code": 500, "detail": str(e)}
            return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class TaskDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, data_id):
        try:
            datarow = HCPRawData.objects.get(id=data_id)
            data_obj = {
                "data_id": datarow.id,
                "task_no": datarow.task_no,
                "row_id_1":datarow.row_id_1,
                "row_id_2": datarow.row_id_2,
                "name_1": datarow.name_1,
                "name_2": datarow.name_2,
                "eid_1": datarow.eid_1,
                "eid_2": datarow.eid_2,
                "prof_desig_1": datarow.prof_desig_1,
                "prof_desig_2": datarow.prof_desig_2,
                "entity_class_1": datarow.entity_class_1,
                "entity_class_2": datarow.entity_class_2,
                "address_1": datarow.address_1,
                "address_1_all": datarow.address_1_all,
                "address_2": datarow.address_2,
                "address_2_all": datarow.address_2_all,
                "npi_1": datarow.npi_1,
                "npi_2": datarow.npi_2,
                "me_1": datarow.me_1,
                "me_2": datarow.me_2,
                "ims_1": datarow.ims_1,
                "ims_2": datarow.ims_2,
                "is_processed": datarow.is_processed,
                "is_merge": datarow.is_merge,
                "comment":datarow.comment,
            }

            data = {
                "code": 200,
                "detail": "Successfully done",
                "data": data_obj
            }
            #time.sleep(10)
            return Response(data, status=status.HTTP_200_OK)
        except  Exception as e:
            print(e)
            data = {"code": 500, "detail": str(e)}
            return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
