import os
import sys
import site

# Add the site-packages of the chosen virtualenv to work with
#site.addsitedir('C:/Users/myuser/Envs/my_application/Lib/site-packages')




# Add the app's directory to the PYTHONPATH
sys.path.append('C:/works/gilead')
sys.path.append('C:/works/gilead/gilead')

os.environ['DJANGO_SETTINGS_MODULE'] = 'gilead.settings'
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "gilead.settings")

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()