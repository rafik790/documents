export const environment = {
  production: true,
  api_baseUrl:"https://bhduhr6dp9.execute-api.us-east-2.amazonaws.com/dev",
};
