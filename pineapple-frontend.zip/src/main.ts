import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import Amplify,{ API } from "aws-amplify";
import aws_exports from "./aws-exports";
//Amplify.configure(aws_exports);
Amplify.configure({
  Auth: {
    mandatorySignIn: true,
    identityPoolId: aws_exports.aws_cognito_identity_pool_id,
    region: aws_exports.aws_cognito_region,
    userPoolId: aws_exports.aws_user_pools_id,
    userPoolWebClientId: aws_exports.aws_user_pools_web_client_id
  },
  API: {
    endpoints: [
      {
        name: "Mygateway",
        endpoint: "https://bhduhr6dp9.execute-api.us-east-2.amazonaws.com/dev",
        region: "us-east-2"
      },
    ]
  }
});

if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
