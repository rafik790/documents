import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Auth } from 'aws-amplify';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  public createForm: FormGroup;
  public restaurants:[];
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createForm = this.fb.group({
      'given_name': ['', Validators.required],
      'family_name': ['', Validators.required],
      'username': ['', Validators.required],
      'email': ['', Validators.required],
      'password': ['', Validators.required],
    });
    
  }

  public async onCreate(data:any){
    console.log(data);
    try {
      
      const { user } = await Auth.signUp({
          username:data.username,
          password:data.password,
          attributes: {
              email:data.email,
              given_name:data.given_name,
              family_name:data.family_name
          }
      });
      
      console.log(user);
    } catch (error) {
        console.log('error signing up:', error);
    }
  }
}
