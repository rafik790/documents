import { EventEmitter, Injectable, Output } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class TokenMangerService {
  @Output() getLoggedInfo: EventEmitter<any> = new EventEmitter();
  constructor() { }

  getAuthenticationToken(){
    let jwtToken = localStorage.getItem("token_pineapple") as string;
    if(jwtToken!=null){
      return jwtToken;
    }

    jwtToken = sessionStorage.getItem("token_pineapple") as string;
    if(jwtToken!=null){
      return jwtToken; 
    }
    return null;
  }

  setAuthenticationToken(user:any,rememberMe:boolean){
    let idToken = user.signInUserSession.idToken;
    if(rememberMe){
      localStorage.setItem("token_pineapple",idToken.jwtToken);
    }else if (window.sessionStorage) {
      sessionStorage.setItem("token_pineapple",idToken.jwtToken);
    }else{
      localStorage.setItem("token_pineapple",idToken.jwtToken);
    }

    let helper = new JwtHelperService();
    let userdetail = helper.decodeToken(idToken.jwtToken);
    this.getLoggedInfo.emit(userdetail);
  }

  get currentUser(){
    let helper = new JwtHelperService();
    let jwtToken = this.getAuthenticationToken();
    if(jwtToken==null){
      return null; 
    }

    if (helper.isTokenExpired(jwtToken)) {
      return null;
    }

    let userdetail = helper.decodeToken(jwtToken);
    return userdetail;
  }

  logout() { 
    let jwtToken = localStorage.getItem("token_pineapple") as string;
    if(jwtToken!=null){
      localStorage.removeItem("token_pineapple");
    }

    jwtToken = sessionStorage.getItem("token_pineapple") as string;
    if(jwtToken!=null){
      sessionStorage.removeItem("token_pineapple");
    }
     
    this.getLoggedInfo.emit(null);
  }

}
