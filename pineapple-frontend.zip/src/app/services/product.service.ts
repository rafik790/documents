import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { catchError, map} from 'rxjs/operators';
import { throwError } from 'rxjs';
import Amplify,{ API } from "aws-amplify";
import { TokenMangerService } from './token-manger.service';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  private baseurl="";
  private apiName:string = 'Mygateway';
  private path = '/api/products';
  private myInit:any;
  constructor(private tokenManger:TokenMangerService) {
    this.baseurl = environment.api_baseUrl;
    let token = tokenManger.getAuthenticationToken();

    this.myInit = { // OPTIONAL
      headers: {
        "Accept":"application/json",
        "Content-Type":"application/json",
        "Authorization":token
      }
    };
  }


  getProducts(pageSize:number,startKey:string) {
    let payload = {
      "pagesize": pageSize,
      "startKey":startKey
    }
    this.myInit.body=payload;

    //return API.get(this.apiName,this.path,this.myInit);
    return API.post(this.apiName,this.path+"/filter",this.myInit);
  }

  addProduct(payload:any) {
    this.myInit.body=payload;
    return API.post(this.apiName,this.path+"/",this.myInit);
  }
}
