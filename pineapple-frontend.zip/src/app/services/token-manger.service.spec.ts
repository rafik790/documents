import { TestBed } from '@angular/core/testing';

import { TokenMangerService } from './token-manger.service';

describe('TokenMangerService', () => {
  let service: TokenMangerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TokenMangerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
