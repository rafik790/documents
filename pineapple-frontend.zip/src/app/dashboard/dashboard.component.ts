import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  startKey:string;
  pageSize:number;
  productList:Array<any>;
  public createForm: FormGroup;
  constructor(private productService:ProductService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder,) {
      this.productList=[];
      this.startKey="";
      this.pageSize = 5;
   }

  ngOnInit(): void {
    this.createForm = this.fb.group({
      'product_name': ['', Validators.required],
      'product_price': ['', Validators.required]
    });
    
    this.getProductList();
  }

 
  getProductList(){
    this.spinner.show();
    const self = this;
    this.productService.getProducts(this.pageSize,this.startKey).then(response => {
      console.log(response);
      console.log(response.Items);
      self.productList = response.Items;
      this.spinner.hide();
    })
    .catch(error => {
      console.log(error.response);
      this.spinner.hide();
    });
  }
  onCreate(data:any){
    this.spinner.show();
    const self = this;
    this.productService.addProduct(data).then(response => {
      console.log(response);
      self.productList.splice(0, 0, response);
      //self.productList.push(response);
      this.spinner.hide();
    })
    .catch(error => {
      console.log(error.response);
      this.spinner.hide();
    });

  }
}
