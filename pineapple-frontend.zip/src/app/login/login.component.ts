import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormFieldTypes } from '@aws-amplify/ui-components';
import { onAuthUIStateChange, CognitoUserInterface, AuthState } from '@aws-amplify/ui-components';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  formFields: FormFieldTypes;
  user: CognitoUserInterface | undefined;
  authState: AuthState;

  constructor(private ref: ChangeDetectorRef) { 
    this.formFields = [
      {
        type: "given_name",
        label: "First Name *",
        placeholder: "First Name",
        required: true,
      },

      {
        type: "family_name",
        label: "Last Name *",
        placeholder: "Last Name",
        required: true,
      },
     
      {
        type: "email",
        label: "Email Address *",
        placeholder: "Email",
        required: true,
      },
      {
        type: "phone_number",
        label: "Phone Number *",
        placeholder: "Phone Number",
        required: false,
      },
      {
        type: "username",
        label: "Username *",
        placeholder: "Username",
        required: true,
      },
      {
        type: "password",
        label: "Password *",
        placeholder: "Password",
        required: true,
      }
    ];
  }

  ngOnInit(): void {
    onAuthUIStateChange((authState, authData) => {
      this.authState = authState;
      this.user = authData as CognitoUserInterface;
      console.log(this.user);
      this.ref.detectChanges();
    });
  }

  ngOnDestroy() {
    return onAuthUIStateChange;
  }

}
