import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Auth } from 'aws-amplify';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { TokenMangerService } from '../services/token-manger.service';

@Component({
  selector: 'app-login-custom',
  templateUrl: './login-custom.component.html',
  styleUrls: ['./login-custom.component.css']
})
export class LoginCustomComponent implements OnInit {
  public signForm: FormGroup;
  constructor(private fb: FormBuilder,
    private toastr: ToastrService,
    private _router: Router,
    private spinner: NgxSpinnerService,
    private tokenService: TokenMangerService) { 
      if(this.tokenService.currentUser!=null){
        this._router.navigate(["/user-dashboard"]);
      }
    }

  ngOnInit(): void {
    this.signForm = this.fb.group({
      'username': ['', Validators.required],
      'password': ['', Validators.required]
    });
  }

  async onSignin(data:any){
    this.spinner.show();
    try {
      const user = await Auth.signIn(data.username, data.password);
      this.tokenService.setAuthenticationToken(user,false);
      this.spinner.hide();
      this._router.navigate(["/user-dashboard"]);
    } catch (error) {
        this.spinner.hide();
        this.toastr.error('', error.message);
    }
  }

}
