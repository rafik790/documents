import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { onAuthUIStateChange, CognitoUserInterface, AuthState } from '@aws-amplify/ui-components';
import { Auth } from 'aws-amplify';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { TokenMangerService } from './services/token-manger.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'angular-cognito-app';
  loggedUserName =""
  constructor(private tokenService: TokenMangerService,
    private toastr: ToastrService,
    private _router: Router,
    private spinner: NgxSpinnerService){
      
    let currentUser = this.tokenService.currentUser;
    if(currentUser!=null){
      this.loggedUserName = currentUser.given_name+" "+currentUser.family_name;
    }else{
      this.loggedUserName='';
    }
  }
  
  ngOnInit(): void {
    this.tokenService.getLoggedInfo.subscribe((currentUser:any)=>{
      if(currentUser!=null){
        this.loggedUserName = currentUser.given_name+" "+currentUser.family_name;
      }else{
        this.loggedUserName='';
      }
      
   });
  }

  async logout(){
    this.spinner.show();
    try {
      await Auth.signOut();
      this.spinner.hide();
      this.tokenService.logout();
      this._router.navigate(["/login"]);
    } catch (error) {
      this.spinner.hide();
      this.toastr.error('', error.message);
    }
  }
}
