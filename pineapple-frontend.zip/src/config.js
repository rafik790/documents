const config = {
    apiGateway: {
      REGION: "us-east-2",
      URL: "YOUR_API_GATEWAY_URL",
    },
    cognito: {
      REGION: "us-east-2",
      USER_POOL_ID: "us-east-2_DDaeYj0GW",
      APP_CLIENT_ID: "2l4kgt7j47u1lhari0leiidstq",
      IDENTITY_POOL_ID: "YOUR_IDENTITY_POOL_ID",
    },
  };
  
  export default config;